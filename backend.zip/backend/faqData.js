export const faq = [
  {
    question: "where is your company located",
    answer: "Our company is located in Bhopal, Madhya Pradesh, India."
  },
  {
    question: "what services do you provide",
    answer: "We provide Web Development, App Development, AI Chatbots, UI/UX Design, Digital Marketing."
  },
  {
    question: "how can i contact you",
    answer: "You can contact us at: support@yourcompany.com or +91-XXXXXXXXXX"
  },
  {
    question: "what are your working hours",
    answer: "We work Monday to Saturday, 9:00 AM to 7:00 PM."
  }
];
